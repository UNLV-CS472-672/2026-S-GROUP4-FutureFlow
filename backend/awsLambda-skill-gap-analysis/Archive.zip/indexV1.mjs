import OpenAI from "openai";
import fs from 'fs';
import { SecretsManagerClient, GetSecretValueCommand } from "@aws-sdk/client-secrets-manager";

let mariadb = null;
let pool = null;
let cachedSecret = null;

// Initialize OpenAI client
const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// --- Helper Functions ---

function escapeRegex(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

async function extractSkillsWithAI(jobDescription) {
  try {
    const response = await client.chat.completions.create({
      model: "gpt-5-nano",
      messages: [
        { role: "system", content: "You extract job skills from job descriptions." },
        {
          role: "user",
          content: `
Extract a list of skills from this job description.
Return ONLY a JSON array of skills (lowercase, no explanation).

Job description:
${jobDescription}
          `
        }
      ]
    });

    const text = response.choices[0]?.message?.content || "";
    return JSON.parse(text);
  } catch (err) {
    console.error("AI extraction failed:", err);
    return [];
  }
}

// Lazy import mariadb
async function getMariadb() {
  if (!mariadb) {
    const mod = await import("mariadb");
    mariadb = mod.default || mod;
  }
  return mariadb;
}

// Fetch DB credentials from AWS Secrets Manager
async function getDbSecret() {
  if (cachedSecret) return cachedSecret;

  const secretArn = process.env.DB_SECRET_ARN;
  if (!secretArn) throw new Error("Missing DB_SECRET_ARN");

  const secretsClient = new SecretsManagerClient({});
  const result = await secretsClient.send(new GetSecretValueCommand({ SecretId: secretArn }));

  if (!result.SecretString) throw new Error("SecretString is empty");

  const parsed = JSON.parse(result.SecretString);
  cachedSecret = { username: parsed.username, password: parsed.password };
  return cachedSecret;
}

// Create/reuse MariaDB pool
async function getPool() {
  if (!pool) {
    const secret = await getDbSecret();
    const mariadbLib = await getMariadb();

    console.log("Files in /var/task:", fs.readdirSync('/var/task'));

    pool = mariadbLib.createPool({
      host: process.env.DB_HOST,
      port: Number(process.env.DB_PORT || 3306),
      user: secret.username,
      password: secret.password,
      database: process.env.DB_NAME,
      connectionLimit: 5,
      ssl: {
        rejectUnauthorized: true,
        ca: fs.readFileSync('/var/task/global-bundle.pem')
      }
    });
  }
  return pool;
}

// Save skill match results to DB
async function saveSkillMatch(userId, jobId, matchScore, matchedSkills, missingSkills) {
  const db = await getPool();
  const conn = await db.getConnection();
  try {
    await conn.query(
      "INSERT INTO skill_matches (user_id, job_id, match_score, matched_skills, missing_skills) VALUES (?, ?, ?, ?, ?)",
      [
        userId,
        jobId,
        matchScore,
        JSON.stringify(matchedSkills),
        JSON.stringify(missingSkills)
      ]
    );
  } finally {
    conn.release();
  }
}

// --- Lambda Handler ---

export const handler = async (event) => {
  try {
    console.log("Handler started");

    const body = JSON.parse(event.body);
    console.log("Parsed body");

    const originalJobDescription = body.jobDescription;
    const jobDescriptionLower = originalJobDescription.toLowerCase();
    const userSkills = body.userSkills.map(s => s.toLowerCase());

    console.log("Before OpenAI call");

    // --- Extract Skills using OpenAI ---
    const jobSkills = await extractSkillsWithAI(originalJobDescription);

    console.log("After OpenAI call:", jobSkills);

    // --- Matching ---
    const matched = jobSkills.filter(skill => userSkills.includes(skill));
    const missing = jobSkills.filter(skill => !userSkills.includes(skill));

    console.log("After matching");

    // --- Ranking Logic ---
    const HIGH_PRIORITY = ["required", "must", "need", "essential", "mandatory"];
    const MEDIUM_PRIORITY = ["preferred", "plus", "beneficial", "desired"];
    const CONTEXT_WORDS = ["experience", "proficient", "knowledge", "familiarity"];

    const rankedSkills = jobSkills.map(skill => {
      let weight = 1;
      const regex = new RegExp(`(.{0,40})\\b${escapeRegex(skill)}\\b(.{0,40})`, 'i');
      const match = originalJobDescription.match(regex);

      if (match) {
        const context = (match[1] + match[2]).toLowerCase();
        HIGH_PRIORITY.forEach(word => { if (context.includes(word)) weight += 3; });
        MEDIUM_PRIORITY.forEach(word => { if (context.includes(word)) weight += 2; });
        CONTEXT_WORDS.forEach(word => { if (context.includes(word)) weight += 1; });
        if (context.includes("not") || context.includes("no")) weight -= 2;
      }

      const occurrences = (jobDescriptionLower.match(new RegExp(escapeRegex(skill), 'gi')) || []).length;
      weight += occurrences;

      return { skill, weight };
    }).sort((a, b) => b.weight - a.weight);

    console.log("After ranking");

    const rankedMissingSkills = rankedSkills
      .filter(item => missing.includes(item.skill))
      .map(item => item.skill);

    const matchScore = jobSkills.length === 0
      ? 0
      : Math.round((matched.length / jobSkills.length) * 100);

    console.log("Before DB save");

    await saveSkillMatch(body.userId, body.jobId, matchScore, matched, rankedMissingSkills);;

    console.log("After DB save");

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        matchScore,
        strengths: matched,
        missingSkills: rankedMissingSkills,
        extractedJobSkills: jobSkills
      }),
    };

  } catch (err) {
    console.error("Handler error:", err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message }),
    };
  }
};