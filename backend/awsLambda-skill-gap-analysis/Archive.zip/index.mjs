import mariadb from 'mariadb';
import { CognitoJwtVerifier } from 'aws-jwt-verify';

// Create MariaDB pool
const pool = mariadb.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  connectionLimit: 5
});

// Cognito verifier setup
const verifier = CognitoJwtVerifier.create({
  userPoolId: process.env.COGNITO_USER_POOL_ID, // e.g., us-east-1_ABC123XYZ
  tokenUse: "access",
  clientId: process.env.COGNITO_APP_CLIENT_ID   // optional, but recommended
});

// DB functions
async function getJobSkills(job_id) {
  const conn = await pool.getConnection();
  try {
    const rows = await conn.query("SELECT extracted_skills FROM job_info WHERE job_id = ?", [job_id]);
    if (rows.length === 0) throw new Error("Job not found");
    return rows[0].extracted_skills || [];
  } finally {
    conn.release();
  }
}

async function getUserSkills(userSub) {
  const conn = await pool.getConnection();
  try {
    const rows = await conn.query("SELECT skills FROM user_info WHERE cognito_sub = ?", [userSub]);
    if (rows.length === 0) throw new Error("User not found");
    return rows[0].skills || [];
  } finally {
    conn.release();
  }
}

// Compute match
function computeMatch(jobSkills, userSkills) {
  const matched = jobSkills.filter(skill => userSkills.includes(skill));
  const missing = jobSkills.filter(skill => !userSkills.includes(skill));
  const score = Math.round((matched.length / (jobSkills.length || 1)) * 100);
  return { score, matched, missing };
}

// Lambda handler
export async function handler(event) {
  try {
    // Extract job_id from request body
    const { job_id } = JSON.parse(event.body);
    if (!job_id) {
      return { statusCode: 400, body: JSON.stringify({ error: "job_id required" }) };
    }

    // Extract accessToken from Authorization header
    const token = event.headers.Authorization?.split(" ")[1];
    if (!token) return { statusCode: 401, body: JSON.stringify({ error: "Missing accessToken" }) };

    // Verify token
    const payload = await verifier.verify(token);
    const userSub = payload.sub; // Cognito unique user ID

    // Fetch skills from DB
    const [jobSkills, userSkills] = await Promise.all([
      getJobSkills(job_id),
      getUserSkills(userSub)
    ]);

    // Compute match
    const matchResult = computeMatch(jobSkills, userSkills);

    return {
      statusCode: 200,
      body: JSON.stringify({
        user_sub: userSub,
        job_id,
        match_score: matchResult.score,
        matched_skills: matchResult.matched,
        missing_skills: matchResult.missing
      })
    };

  } catch (err) {
    console.error("Handler error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
}